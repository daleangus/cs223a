"""
rbdl.py

Author: Toki Migimatsu
Created: December 2017
"""

import numpy as np
import ctypes as c

import os
rbdl_py = c.cdll.LoadLibrary(os.path.join(os.path.dirname(__file__), "librbdlpy.so"))

c_double_p = c.POINTER(c.c_double)

rbdl_init = rbdl_py.init
rbdl_init.restype  = c.c_void_p
rbdl_init.argtypes = None

rbdl_set_gravity = rbdl_py.set_gravity
rbdl_set_gravity.restype  = None
rbdl_set_gravity.argtypes = [c.c_void_p, # rbdl
                             c.c_double, # g_x
                             c.c_double, # g_y
                             c.c_double] # g_z

rbdl_add_link = rbdl_py.add_link
rbdl_add_link.restype  = None
rbdl_add_link.argtypes = [c.c_void_p, # rbdl
                          c_double_p, # displacement
                          c_double_p, # zyx_euler
                          c.c_ubyte,  # joint_type
                          c_double_p, # joint_axis
                          c.c_double, # mass
                          c_double_p, # com
                          c_double_p] # inertia_C

rbdl_forward_dynamics = rbdl_py.forward_dynamics
rbdl_forward_dynamics.restype  = None
rbdl_forward_dynamics.argtypes = [c.c_void_p, # rbdl
                                  c_double_p, # q
                                  c_double_p, # dq
                                  c_double_p, # tau
                                  c_double_p] # ddq
 
class Rbdl:

    JointTypeRevolute  = 0
    JointTypePrismatic = 1

    def __init__(self):
        self.rbdl = rbdl_init()
        self.dof  = 0

    def set_gravity(self, g_x, g_y, g_z):
        rbdl_set_gravity(self.rbdl,
                         c.c_double(g_x),
                         c.c_double(g_y),
                         c.c_double(g_z))

    def add_link(self, rotation, translation, joint_type, joint_axis, mass, com, inertia_C):
        rotation    = np.array(rotation, dtype=np.float64)
        translation = np.array(translation, dtype=np.float64)
        joint_axis  = np.array(joint_axis, dtype=np.float64)
        com         = np.array(com, dtype=np.float64)
        inertia_C   = np.array(inertia_C, dtype=np.float64)
        rbdl_add_link(self.rbdl,
                      rotation.ctypes.data_as(c_double_p),
                      translation.ctypes.data_as(c_double_p),
                      c.c_ubyte(joint_type),
                      joint_axis.ctypes.data_as(c_double_p),
                      c.c_double(mass),
                      com.ctypes.data_as(c_double_p),
                      inertia_C.ctypes.data_as(c_double_p))
        self.dof += 1

    def forward_dynamics(self, q, dq, tau):
        q   = np.array(q, dtype=np.float64)
        dq  = np.array(dq, dtype=np.float64)
        tau = np.array(tau, dtype=np.float64)
        ddq = np.zeros(self.dof, dtype=np.float64)
        rbdl_forward_dynamics(self.rbdl,
                              q.ctypes.data_as(c_double_p),
                              dq.ctypes.data_as(c_double_p),
                              tau.ctypes.data_as(c_double_p),
                              ddq.ctypes.data_as(c_double_p))
        return ddq

