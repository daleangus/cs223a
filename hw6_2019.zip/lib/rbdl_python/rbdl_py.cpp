/**
 * rbdl_py.cpp
 *
 * Author: Toki Migimatsu
 * Created: December 2017
 */

#include <Python.h>
#include <rbdl/rbdl.h>
#include <Eigen/Core>
#include <memory>

extern "C" {
	void *init();

	void set_gravity(void *p_robot,
	                 double g_x,
	                 double g_y,
	                 double g_z);

	void add_link(void *p_robot,
	              const double *rotation,
	              const double *translation,
	              uint8_t joint_type,
	              const double *joint_axis,
	              double mass,
	              const double *com,
	              const double *inertia_C);

	void forward_dynamics(void *p_robot,
	                      const double *q,
	                      const double *dq,
	                      const double *tau,
	                      double *ddq);
}

namespace Rbdl = RigidBodyDynamics;

static const uint8_t JointTypeRevolute = 0;
static const uint8_t JointTypePrismatic = 1;

class Robot {
	public:
		Robot() {
			model_->gravity = Eigen::Vector3d(0, 0, -9.81);
		}

		void set_gravity(double g_x, double g_y, double g_z) {
			model_->gravity = Eigen::Vector3d(g_x, g_y, g_z);
		}

		void add_link(const double *a_rotation,
		              const double *a_translation,
		              uint8_t a_joint_type,
		              const double *a_joint_axis,
		              double mass,
		              const double *a_com,
		              const double *a_inertia_C)
		{
			Eigen::Matrix3d rotation = Eigen::Map<const Eigen::Matrix3d>(a_rotation);
			Eigen::Vector3d translation = Eigen::Map<const Eigen::Vector3d>(a_translation);
			Rbdl::JointType joint_type;
			switch(a_joint_type) {
				case JointTypeRevolute:
					joint_type = Rbdl::JointTypeRevolute;
					break;
				case JointTypePrismatic:
					joint_type = Rbdl::JointTypePrismatic;
					break;
			}
			Eigen::Vector3d joint_axis = Eigen::Map<const Eigen::Vector3d>(a_joint_axis);
			Eigen::Vector3d com = Eigen::Map<const Eigen::Vector3d>(a_com);
			Rbdl::Math::Matrix3d inertia_C = Eigen::Map<const Eigen::Matrix<double,3,3,Eigen::RowMajor>>(a_inertia_C);
			// std::cout << "R: " << rotation << std::endl
			//     << "p: " << translation.transpose() << std::endl
			//     << "type: " << a_joint_type << std::endl
			//     << "axis: " << joint_axis.transpose() << std::endl
			//     << "com: " << com.transpose() << std::endl
			//     << "I: " << inertia_C << std::endl << std::endl;

			// Rbdl::Math::SpatialTransform joint_frame = Rbdl::Math::XtransRotZYXEuler(displacement, zyx_euler);
			Rbdl::Math::SpatialTransform joint_frame(rotation, translation);
			Rbdl::Joint joint(joint_type, joint_axis);
			Rbdl::Body body(mass, com, inertia_C);
			id_last_ = model_->AddBody(id_last_, joint_frame, joint, body);
			dof_++;
		}

		void forward_dynamics(const double *a_q,
		                      const double *a_dq,
		                      const double *a_tau,
		                      double *a_ddq)
		{
			Eigen::VectorXd q   = Eigen::Map<const Eigen::VectorXd>(a_q, dof_);
			Eigen::VectorXd dq  = Eigen::Map<const Eigen::VectorXd>(a_dq, dof_);
			Eigen::VectorXd tau = Eigen::Map<const Eigen::VectorXd>(a_tau, dof_);
			Eigen::VectorXd ddq(dof_);

			Rbdl::ForwardDynamics(*model_, q, dq, tau, ddq);

			Eigen::Map<Eigen::VectorXd> ret_ddq(a_ddq, dof_);
			ret_ddq = ddq;
		}

	private:
		std::unique_ptr<Rbdl::Model> model_ = std::unique_ptr<Rbdl::Model>(new Rbdl::Model());
		unsigned int id_last_ = 0;
		unsigned int dof_     = 0;
};

void *init() {
	return new Robot();
}

void set_gravity(void *p_robot, double g_x, double g_y, double g_z)
{
	Robot *robot = reinterpret_cast<Robot *>(p_robot);
	robot->set_gravity(g_x, g_y, g_z);
}

void add_link(void *p_robot,
              const double *rotation,
              const double *translation,
              uint8_t joint_type,
              const double *joint_axis,
              double mass,
              const double *com,
              const double *inertia_C)
{
	Robot *robot = reinterpret_cast<Robot *>(p_robot);
	robot->add_link(rotation, translation, joint_type, joint_axis, mass, com, inertia_C);
}

void forward_dynamics(void *p_robot,
                      const double *q,
                      const double *dq,
                      const double *tau,
                      double *ddq)
{
	Robot *robot = reinterpret_cast<Robot *>(p_robot);
	robot->forward_dynamics(q, dq, tau, ddq);
}
